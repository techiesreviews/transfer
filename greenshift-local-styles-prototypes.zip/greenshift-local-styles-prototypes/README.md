# GreenShift “Local Styles”: alternatives to the tab grid

Interactive UX prototypes for the Local Styles panel in the Gutenberg block sidebar (280px wide). They're static HTML with no dependencies and no build step. Everything is mocked, so no WordPress is needed.

## How to open

Unzip the folder and double-click `index.html`. It opens in any browser and works offline.

- `mix.html` has the proposed direction. Start here. (`index.html` also links to it.)
- `index.html` has the first round: six different ways to replace the tab grid.
- `shots/` has screenshots of every prototype, in case you only want to skim.

## The problem with the current tab grid

- You can't see what's inside a tab without clicking it ("what's in Effects?").
- A blue dot says that something is set, but not what.
- There are 11 categories of equal weight, so padding sits at the same level as blend modes.
- Labels get cut off ("Transit.", "Shad…"), and the stacked rows reflow as the sidebar width changes.
- You can't see two categories at once.

## Proposed direction: `mix.html` → variant A

This takes prototype #4 and adds #3's search:

1. **One scroll.** All categories are open in a single list, and nothing hides behind tabs.
2. **A sticky jump bar.** A row of category chips stays at the top. Clicking a chip scrolls to that section, and the chip for the section you're in is highlighted as you scroll. A dot marks categories that have values set.
3. **A search box that opens a catalog.** Clicking it lists every property, grouped by category, with a one-line description ("Radius: rounded corners") and its current value. Typing narrows the list and matches synonyms ("rounded" finds Radius, "transparent" finds Opacity). Picking a result scrolls to that control, highlights it and focuses it.
4. **A "Set (n)" toggle.** One click shows only the styles this block changes.

Variants B–D in `mix.html` are the alternatives we considered, and each card lists its trade-offs.

## Notes for building it

- Every prototype's JS and CSS is inside its HTML file. The category and property data, including the descriptions and search keywords, is the `CATS` array at the top of the script. Reuse the synonyms: they're what makes search useful.
- Put State (Normal/Hover) and Device in one bar above everything, rather than adding more tabs.
- Order categories by how often they're used (Spacing, Layout, Typography, Colors, …), with Transition, Effects and CSS last.
- The prototypes imitate core Gutenberg styling (`SearchControl`, `ToggleGroupControl`, `ToolsPanel` look), so it should map onto `@wordpress/components`.
